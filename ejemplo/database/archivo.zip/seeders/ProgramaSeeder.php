<?php

namespace Database\Seeders;

use Illuminate\Support\Facades\DB;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class ProgramaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('programas')->insert([
            'nombres'=>"Ingenieria de Sistema e Informatica",
        ]); 

        DB::table('programas')->insert([
            'nombres'=>"Derecho y Ciencias Politicas",
        ]); 
    }
}
